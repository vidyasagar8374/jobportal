<h1>Hi, <?php echo e($name); ?></h1>
<p>Welcome mail from job portal for <?php echo e($role == 5 ? 'Hr' : 'sales'); ?> Position. you can login now,</p>
<p>Email : <?php echo e($email); ?></p>
<p>Password : <?php echo e($password); ?></p>
<a href="https://jobportal.softhouz.com/Userlogin" >Click Here to login !</a>

<?php /**PATH C:\xampp_8.1\htdocs\jobportal\jobportal_php\jobportal_php\resources\views/mails/HrOrMarketer.blade.php ENDPATH**/ ?>