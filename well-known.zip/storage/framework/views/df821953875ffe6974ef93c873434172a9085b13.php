<div id="tag_container" class="container">
<table>
<tbody>
<tr>
<th rowspan="2"><strong>Candidate id</strong></th>
<th rowspan="2"><strong>Name</strong></th>
<th rowspan="2"><strong>Email</strong></th>
<th rowspan="2"><strong>Location</strong></th>
<th colspan="3"><strong>Work Authorization</strong></th>
<th colspan="2"><strong>Expected Rate/Salary </strong></th>
<th colspan="2"><strong>Experience</strong></th>
</tr>
<tr>
<th>Relocate</th>
<th>Travel</th>
<th>Relocate</th>
<th>Salary</th>
<th>Hourly</th>
<th>Skills</th>
<th>Years</th>
</tr>
<?php if(count($data) == 0): ?>
<td colspan="11">No Data Found</td>
<?php else: ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tr>
<td><?php echo e($info->candidatedetails->id); ?></td>
<td><?php echo e($info->candidatedetails->firstname); ?> <?php echo e($info->candidatedetails->lastname); ?></td>
<td><?php echo e($info->candidatedetails->contactemail); ?></td>
<td><?php echo e($info->candidatedetails->location); ?></td>
<td><?php echo e($info->candidatedetails->relocate == 1 ? 'Yes' : ($info->candidatedetails->relocate == 2 ? 'No' : 'NA')); ?></td>
<td><?php echo e($info->candidatedetails->travel == 1 ? 'Yes' : ($info->candidatedetails->travel == 2 ? 'No' : 'NA')); ?></td>
<td><?php echo e($info->candidatedetails->employee); ?></td>
<td><?php echo e($info->candidatedetails->expectedate); ?></td>
<td><?php echo e($info->candidatedetails->salarytype); ?></td>
<td>
<?php $__currentLoopData = $info->candidateskills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $skills): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($skills->skillname->techonology); ?> <?php echo e($index + 1 < count($info->candidateskills) ? ',' : ''); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>
<td><?php echo e($info->candidatedetails->experience); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</tbody>
</table>
<div id="pagination-container" style="margin-top:15px">
    <?php echo e($data->links()); ?>

</div>
</div>

<?php
$url = '/applications-recived/80'
?>
<script>
  document.getElementById('pagination-container').addEventListener('click', function(event) {
      event.preventDefault();
      const url = new URL(event.target.href);
      const pageNumber = url.searchParams.get('page');
      debugger
      getapplicantsdata(pageNumber)
    });
    function getapplicantsdata(page){
    // var skill = $('#multiple-select').val();
    // var level = $('#level').val();
    // var exp1 = $('#fromSlider').val();
    // var exp2 = $('#toSlider').val();
    // var mode = $('#mode').val();
    // var salary = $('#salary').val();
    // var type = $('#type').val();
    debugger
    $.ajax({
          url: <?php echo json_encode($url, 15, 512) ?>,
          method: "POST",
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          data: {
            // level: level,
            //   exp1: exp1,
            //   exp2: exp2,
            //   mode: mode,
            //   salary: salary,
            //   skill: skill,
              page: page
          },
          success: function(response) {
              $('#tag_container').html(response.html);
              // initializeStatusDropdowns();
          }
      });
    }
  </script><?php /**PATH C:\xampp_8.1\htdocs\jobportal\jobportal_php\jobportal_php\resources\views/jobs/applications.blade.php ENDPATH**/ ?>