<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>DesignAlley Dashboard</title>
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta property="og:title" content="" />
    <meta property="og:type" content="" />
    <meta property="og:url" content="" />
    <meta property="og:image" content="" />
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets1/imgs/theme/fav-da.png" />
    <!-- Template CSS -->
    <!-- <link href="assets1/css/main.css?v=1.1" rel="stylesheet" type="text/css" /> -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link href="<?php echo e(asset('assets1/css/mainnodatatable.css?v=1.1')); ?>" rel="stylesheet" type="text/css" />
    <style>
   body {
        margin: 0;
        overflow: hidden;
    }
    iframe {
        width: 100%;
        height: calc(100vh - 10px);
        border: none;
    }
    .modal-container {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 9999; /* Ensure modal is above other elements */
        background-color: #fff; /* Optional: Set a background color for the modal */
        padding: 20px; /* Optional: Adjust padding as needed */
        max-width: 90%; /* Optional: Set maximum width for the modal */
        max-height: 90%; /* Optional: Set maximum height for the modal */
        overflow-y: auto; /* Optional: Enable vertical scrolling if content exceeds modal height */
        border-radius: 8px; /* Optional: Add rounded corners to the modal */
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* Optional: Add shadow for depth effect */
    }

        body {
            margin: 0; /* Remove default margin */
            overflow: hidden; /* Hide body overflow to prevent double scrollbar */
        }
        iframe {
            width: 100%;
            height: calc(100vh - 10px); /* Adjust iframe height based on remaining viewport height */
            border: none;
        }
    </style>
</head>

<body>
    <div class="screen-overlay"></div>
    <?php echo $__env->make('Employer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <main class="main-wrap">
        <header class="main-header navbar">
            <div class="col-search">
                <form class="searchform">
                    <div class="input-group">
                        <!--<input list="search_terms" type="text" class="form-control" placeholder="Search term" />-->
                        <!--<button class="btn btn-light bg" type="button"><i class="material-icons md-search"></i></button>-->
                    </div>
                    <datalist id="search_terms">
                        <option value="Products"></option>
                        <option value="New orders"></option>
                        <option value="Apple iphone"></option>
                        <option value="Ahmed Hassan"></option>
                    </datalist>
                </form>
            </div>
            <div class="col-nav">
                <button class="btn btn-icon btn-mobile me-auto" data-trigger="#offcanvas_aside"><i class="material-icons md-apps"></i></button>
                <ul class="nav">
                   
                </ul>
            </div>
        </header>
        <section class="content-main">
            <iframe src="http://localhost:3000/" title="description"></iframe>
            <!-- card end// -->
        </section>
    </main>
    <script src="assets1/js/vendors/jquery-3.6.0.min.js"></script>
    <script src="assets1/js/vendors/bootstrap.bundle.min.js"></script>
    <script src="assets1/js/vendors/select2.min.js"></script>
    <script src="assets1/js/vendors/perfect-scrollbar.js"></script>
    <script src="assets1/js/vendors/jquery.fullscreen.min.js"></script>
    <!-- Main Script -->
    <script src="assets1/js/main.js?v=1.1" type="text/javascript"></script>
</body>
</html>
<?php /**PATH C:\xampp_8.1\htdocs\jobportal\jobportal_php\jobportal_php\resources\views/Employee/jobdata.blade.php ENDPATH**/ ?>