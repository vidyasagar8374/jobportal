<h1>Hi, {{ $name }}</h1>
<p>Welcome mail from job portal for {{$role == 5 ? 'Hr' : 'sales'}} Position. you can login now,</p>
<p>Email : {{$email}}</p>
<p>Password : {{$password}}</p>
<a href="https://jobportal.softhouz.com/Userlogin" >Click Here to login !</a>

