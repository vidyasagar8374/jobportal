<?php

namespace App\Http\Controllers\employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Jobpost;
use App\Models\Techonology;
use App\Models\Employercandidate;
use App\Models\Jobsapplied;
use App\Models\User;
use Illuminate\Support\Facades\Redirect;


class JobsApplyController extends Controller
{
    public function ApplyJob(Request $request)
    {
        return view('Employee.jobdata');

        // new code

        $user=User::where('email','=', \Auth::user()->email)->first();
        if (!$userToken=\JWTAuth::fromUser($user)) {
        return response()->json(['error' => 'invalid_credentials'], 401);
        }
        return view('redirect')->with('userToken', $userToken);
        return redirect()->away('http://localhost:3000/?token=' . $userToken)->with('target', '_blank');

        // end of new code

        $techonologies = Techonology::select('techonology', 'id')->get();
        if(\Auth::user()->role === 4 || \Auth::user()->role === 5){
             $candidateslist = Employercandidate::where('Employerid', \Auth::user()->belongsto)->select('id', 'firstname', 'email')->get();
        }else{
            $candidateslist = Employercandidate::where('Employerid', \Auth::user()->id)->select('id', 'firstname', 'email')->get();
        }
        if(isset($request->tech)){
            $list = \DB::table('jobpostsskills')->whereIn('techonology_id', $request->tech)->distinct()->pluck('jobid');
            $Posts = Jobpost::with(['jobskills.info', 'appliedinfo'])->where('isactive', 1)->whereIn('id', $list)->whereNull('is_closed')->latest('id')->distinct()->paginate(10);
        }
        else{
            $Posts = Jobpost::with(['jobskills.info', 'appliedinfo'])->where('isactive', 1)->whereNull('is_closed')->latest('id')->paginate(10);
        }
        if ($request->ajax()) {
            $view = view('Employee/paginatedashboardapply',compact('Posts'))->render();
            return response()->json(['html'=>$view]);
        }
        // dd(111);
        return view('Employee/Dashboard2', compact('Posts', 'techonologies', 'candidateslist'));
    }
    public function applyCandidateJob(Request $request)
    {
        try{
            foreach($request->candidates as $candidate){
                $applyJob = new Jobsapplied;
                $applyJob->user_id = $candidate;
                $applyJob->jobid = $request->jobid;
                $applyJob->isactive = 1;
                $applyJob->save();
            }
            return 1;
        }catch(\Exception $e){
            \Log::error($e);
            return 0;
        }
    }
 
}
