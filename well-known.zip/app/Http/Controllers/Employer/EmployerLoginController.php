<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EmployerLoginController extends Controller
{
    public function EmployerRegister()
    {
        dd('sadsadsadsdsdsds');
    }
}
