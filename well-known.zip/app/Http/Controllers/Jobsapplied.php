<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Jobsapplied extends Controller
{
    //
    protected $table = 'jobsapplied';
}
